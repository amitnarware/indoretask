const express = require('express')
const userRouter = require('./routes/users.route');
const productRouter = require('./routes/products.route');
const app = express();
app.use(express.json());
 
app.use('/',userRouter)
app.use('/product',productRouter);

const PORT = 4000;
app.listen( PORT,()=>{
    console.log(`Server is running on ${PORT}`)
})