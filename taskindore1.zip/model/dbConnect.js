var mysql = require("mysql");
var connection = mysql.createConnection({
    user:"root",
    host:"localhost",
    password:"",
    port:3306,
    database:"myproducts"
});

connection.connect((err) =>{
    if (err) {
        console.log("error occured...", err.sqlMessage);             
    } else {
        console.log("Connection Established...")
    }
})

module.exports = connection;