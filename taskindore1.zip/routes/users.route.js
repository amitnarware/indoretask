const express = require("express")
const userRouter =  express.Router();

const {userLogin,userSignup} = require("../controllers/user");
userRouter.post ('/signup',userSignup);
userRouter.post ('/login',userLogin);

module.exports =  userRouter;
