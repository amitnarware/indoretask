const express = require("express")
const productRouter =  express.Router();

const {viewProduct} = require("../controllers/products");

productRouter.get ('/view',viewProduct);       

module.exports =  productRouter;
