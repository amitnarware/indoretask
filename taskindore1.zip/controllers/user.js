const db = require("../model/dbConnect");
const bcrypt = require("bcrypt");
 const jwt =  require ("jsonwebtoken");
const userSignup = async (req, res) => {
    const { user_id, username, password } = req.body;
    bcrypt.hash(password, 10, (err, hash) => {
        if (err) {
            return res.status(500).json({ error: err.message })
        }
        db.query(
            'INSERT INTO users(user_id,username,password) values (?,?,?)',
            [user_id, username, hash],
            (err, results) => {
                if (err) {
                    return res.status(500).json({ error: err.message })
                }
                res.status(201).json({ message: 'User registered succesfully' });
            }
        )
    })
};

//LOGIN

const userLogin = async (req, res) => {
    const { user_id, password } = req.body;
    db.query(
        'select * from users WHERE user_id = ?',
        [user_id],
        (err, results) => {
            if (err) {
                return res.status(500).json({ error: err.message })
            }
            if (results.length === 0) {
                return res.status(401).json({ message: 'Authentication failed' });
            }

            const user = results[0];
            bcrypt.compare(req.body.password.toString(), (err, isValid) => {
                if (err) {
                    return res.status(500).json({ error: err.message })
                }
                if (isValid) {
                    return res.status(401).json({ message: 'Authentication failed' })
                }
                const token = jwt.sign({userId:user.user_id}, "SECRET_KEY",{
                    expiresIn:'1h'
                })
                res.json({token})
            })
        }
    )
}

module.exports = {userSignup,userLogin}