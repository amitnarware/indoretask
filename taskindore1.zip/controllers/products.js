const db = require ('../model/dbConnect');

const viewProduct = async  (req,res) =>{
    try {
        let data = req.body;
        let sql = "SELECT SUM(price) FROM product WHERE scid IN(SELECT scid FROM sub_category WHERE cid = (SELECT cid FROM category))";
        console.log(sql)
        await db.query(sql,data,(err,results)=>{
            if (err) {
                console.log("error==", err.sqlMessage);
            } else {
              res.json(results)  
            }
        })
    } catch (error) {
        res.send(error.sqlMessage);
    }
}

module.exports = { viewProduct};